// Kusubiri ukurasa umalize kupakia (DOM)
document.addEventListener("DOMContentLoaded", () => {
    
    // 1. UTANGAULIZI WA FOMU YA LOGIN
    const loginForm = document.querySelector("#login-form"); // Weka id="login-form" kwenye fomu ya login
    if (loginForm) {
        loginForm.addEventListener("submit", (e) => {
            e.preventDefault();
            alert("Umeingia kwenye mfumo kwa mafanikio!");
            window.location.href="index.html";
            loginForm.reset();
        });
    }

    // 2. FOMU YA KUONGEZA MWANAFUNZI MPYA
    const regForm = document.querySelector("#registration-form"); // Weka id="registration-form" kwenye fomu ya usajili
    const studentTableBody = document.querySelector("#student-table-body"); // Weka id="student-table-body" kwenye <tbody> ya jedwali

    if (regForm && studentTableBody) {
        regForm.addEventListener("submit", (e) => {
            e.preventDefault();

            // Kuchukua thamani (values) kutoka kwenye fomu
            const name = document.querySelector("#student-name").value;
            const studentId = document.querySelector("#student-id").value;
            const email = document.querySelector("#student-email").value;
            const phone = document.querySelector("#student-phone").value;
            const gender = document.querySelector("#student-gender").value;
            const dob = document.querySelector("#student-dob").value;
            const level = document.querySelector("#student-level").value;

            // Kutengeneza mstari mpya (row) wa jedwali
            const newRow = document.createElement("tr");
            newRow.innerHTML = `
                <td>${name}</td>
                <td>${studentId}</td>
                <td>${email}</td>
                <td>${phone}</td>
                <td>${gender}</td>
                <td>${dob}</td>
                <td>${level}</td>
                <td>
                    <button class="btn-view">View</button>
                    <button class="btn-edit">Edit</button>
                    <button class="btn-delete" style="color: red;">Delete</button>
                </td>
            `;

            // Kuongeza mstari kwenye jedwali letu la HTML
            studentTableBody.appendChild(newRow);

            // Kusafisha fomu baada ya kutuma taarifa
            regForm.reset();
            alert(`Mwanafunzi ${name} ameongezwa kikamilifu!`);
        });
    }

    // 3. SHUGHULIKIA VITUFE VYA "VIEW", "EDIT", NA "DELETE"
    if (studentTableBody) {
        studentTableBody.addEventListener("click", (e) => {
            const clickedButton = e.target;
            const row = clickedButton.closest("tr");
            const studentName = row.cells[0].innerText;

            // Kitufe cha Kufuta (Delete)
            if (clickedButton.classList.contains("btn-delete")) {
                if (confirm(`Je, una uhakika unataka kumfuta ${studentName}?`)) {
                    row.remove();
                    alert("Mwanafunzi amefutwa.");
                }
            }
            
            // Kitufe cha Kuangalia (View)
            if (clickedButton.classList.contains("btn-view")) {
                alert(`Taarifa za Mwanafunzi:\nJina: ${studentName}\nID: ${row.cells[1].innerText}\nNgazi: ${row.cells[6].innerText}`);
            }
            
            // Kitufe cha Kuhariri (Edit)
            if (clickedButton.classList.contains("btn-edit")) {
                alert(`Unakaribia kuhariri taarifa za ${studentName}\nID:${row.cells[2].innerText}\nNgazi:${row.cells[6].innerText}`);
            }
        });
    }
});
// 1. Orodha ya wanafunzi wa mfano (Default Data) kulingana na jedwali lako la HTML
const wanafunziWaMfano = [
    { name: "Ally shabani", id: "25100534760110", email: "ali2026@gmail.com", phone: "255745845576", gender: "Male", dob: "2004", level: "Form six" },
    { name: "Pius vicent", id: "25100534760110", email: "vicentpius@gmail.com", phone: "255747845576", gender: "Male", dob: "2006", level: "Form five" },
    { name: "Mwajuma phabian", id: "25100534760117", email: "mwajuma@gmail.com", phone: "255745840976", gender: "Female", dob: "2005", level: "Form six" },
    { name: "Juma idd", id: "25100534760009", email: "ali2026@gmail.com", phone: "255745848976", gender: "Male", dob: "2009", level: "Form three" },
    { name: "Mary maick", id: "25100534760078", email: "mary116@gmail.com", phone: "255745804576", gender: "Female", dob: "2008", level: "Form four" }
];

// Angalia kama kuna data kwenye localStorage, kama hakuna weka zile za mfano
if (!localStorage.getItem('wanafunzi')) {
    localStorage.setItem('wanafunzi', JSON.stringify(wanafunziWaMfano));
}

// 2. KUSHUGHULIKIA FOMU YA USAJILI (Inafanya kazi mtumiaji akiwa kwenye fomu)
const fomuYaUsajili = document.getElementById('registration-form');
if (fomuYaUsajili) {
    fomuYaUsajili.addEventListener('submit', function(event) {
        event.preventDefault(); // Kuzuia ukurasa usijirudie (refresh)

        // Kuchukua data kutoka kwenye fomu
        const mwanafunziMpya = {
            name: document.getElementById('student-name').value,
            id: document.getElementById('student-id').value,
            email: document.getElementById('student-email').value,
            phone: document.getElementById('student-phone').value,
            gender: document.getElementById('student-gender').value,
            dob: document.getElementById('student-dob').value,
            level: document.getElementById('student-level').value
        };

        // Kuchukua orodha iliyopo kwenye localStorage
        let orodhaYote = JSON.parse(localStorage.getItem('wanafunzi'));

        // Kuongeza mwanafunzi mpya
        orodhaYote.push(mwanafunziMpya);

        // Kuhifadhi upya kwenye localStorage
        localStorage.setItem('wanafunzi', JSON.stringify(orodhaYote));

        // Kusafisha fomu na kumpeleka mtumiaji kwenye ukurasa wa jedwali
        fomuYaUsajili.reset();
        window.location.href = 'students.html'; // Badili hapa iende kwenye jina halisi la faili yako ya jedwali
    });
}

// 3. KUSHUGHULIKIA JEDWALI LA WANAFUNZI (Inafanya kazi mtumiaji akiwa kwenye jedwali)
const jedwaliBody = document.getElementById('student-table-body');
if (jedwaliBody) {
    // Kazi ya kuonyesha data kwenye jedwali
    function onyeshaWanafunzi() {
        const orodhaYote = JSON.parse(localStorage.getItem('wanafunzi'));
        jedwaliBody.innerHTML = ''; // Kusafisha jedwali la zamani lililoandikwa kwa mkono

        orodhaYote.forEach((mwanafunzi, index) => {
            const row = `
                <tr>
                    <td>${mwanafunzi.name}</td>
                    <td>${mwanafunzi.id}</td>
                    <td>${mwanafunzi.email}</td>
                    <td>${mwanafunzi.phone}</td>
                    <td>${mwanafunzi.gender}</td>
                    <td>${mwanafunzi.dob}</td>
                    <td>${mwanafunzi.level}</td>
                    <td>
                        <button class="btn-view" onclick="angaliaMwanafunzi(${index})">View</button>
                        <button class="btn-edit" onclick="haririMwanafunzi(${index})">Edit</button>
                        <button class="btn-delete" onclick="futaMwanafunzi(${index})">Delete</button>
                    </td>
                </tr>
            `;
            jedwaliBody.innerHTML += row;
        });
    }

    // Amri ya kufuta mwanafunzi
    window.futaMwanafunzi = function(index) {
        let orodhaYote = JSON.parse(localStorage.getItem('wanafunzi'));
        if (confirm(`Je, una uhakika unataka kumfuta ${orodhaYote[index].name}?`)) {
            orodhaYote.splice(index, 1); // Kuondoa mwanafunzi kwenye array
            localStorage.setItem('wanafunzi', JSON.stringify(orodhaYote)); // Kusave upya
            onyeshaWanafunzi(); // Kuonyesha jedwali lililosafishwa
        }
    };

    // Amri za View na Edit unaweza kuziongezea mifumo unayoitaka baadae
    window.angaliaMwanafunzi = function(index) {
        const orodhaYote = JSON.parse(localStorage.getItem('wanafunzi'));
        alert(`Taarifa za Mwanafunzi:\n\nJina: ${orodhaYote[index].name}\nID: ${orodhaYote[index].id}\nEmail: ${orodhaYote[index].email}`);
    };

    window.haririMwanafunzi = function(index) {
        alert("Sehemu ya kuhariri (Edit) inaweza kutengenezwa kulingana na jinsi unavyotaka kuivuta data kurudi kwenye fomu.");
    };

    // Washa kazi ya kuonyesha jedwali ukurasa unapofunguka
    onyeshaWanafunzi();
}



    