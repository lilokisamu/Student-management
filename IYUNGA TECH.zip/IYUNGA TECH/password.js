function tumaBaruaPepe(event) {
    event.preventDefault(); // Inazuia ukurasa usijirefresh

    const email = document.getElementById("forgotEmail").value;
    const messageDisplay = document.getElementById("message");

    messageDisplay.style.color = "blue";
    messageDisplay.innerText = "Inatuma, tafadhali subiri...";

    // Tuma data kwenda kwenye Java Servlet (badili URL kulingana na mazingira yako)
    fetch("http://localhost:8080/yako-app/ForgotPasswordServlet", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
        body: "email=" + encodeURIComponent(email)
    })
    .then(response => response.text())
    .then(data => {
        if (data === "success") {
            messageDisplay.style.color = "green";
            messageDisplay.innerText = "Msimbo wa siri au link imetumwa kwenye barua pepe yako!";
        } else {
            messageDisplay.style.color = "red";
            messageDisplay.innerText = "Barua pepe hii haijasajiliwa!";
        }
    })
    .catch(error => {
        messageDisplay.style.color = "red";
        messageDisplay.innerText = "Imeshindwa kuunganisha kwenye seva. Jaribu tena.";
        console.error("Error:", error);
    });
}
